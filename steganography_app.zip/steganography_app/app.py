from flask import Flask, render_template, request, send_file
from PIL import Image
import numpy as np
from cryptography.fernet import Fernet
import base64
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# --- Encoding Functions ---
def generate_key(secret_key):
    key = base64.urlsafe_b64encode(secret_key.ljust(32)[:32].encode())
    return Fernet(key)

def encrypt_message(message, secret_key):
    f = generate_key(secret_key)
    encrypted = f.encrypt(message.encode())
    return encrypted

def text_to_bits(text):
    bits = ''.join(format(byte, '08b') for byte in text)
    return bits

def encode_image(image_file, message, secret_key):
    img = Image.open(image_file).convert('RGB')
    img_array = np.array(img)
    
    encrypted_msg = encrypt_message(message, secret_key)
    bits = text_to_bits(encrypted_msg)
    bits += '11111111'  # Delimiter
    
    if len(bits) > img_array.size:
        raise ValueError("The message is too big to hide in this image!")
    
    flat_img = img_array.flatten()
    for i, bit in enumerate(bits):
        flat_img[i] = (flat_img[i] & 0xFE) | int(bit)
    
    encoded_array = flat_img.reshape(img_array.shape)
    encoded_img = Image.fromarray(encoded_array.astype('uint8'))
    
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], 'encoded_image.png')
    encoded_img.save(output_path)
    
    return output_path

# --- Decoding Functions ---
def decrypt_message(encrypted_msg, secret_key):
    f = generate_key(secret_key)
    try:
        decrypted = f.decrypt(encrypted_msg).decode()
        return decrypted
    except Exception as e:
        return None

def bits_to_bytes(bits):
    byte_array = bytearray()
    for i in range(0, len(bits) - 8, 8):
        byte_bits = bits[i:i+8]
        if byte_bits == '11111111':
            break
        byte_array.append(int(byte_bits, 2))
    return bytes(byte_array)

def decode_image(image_file, secret_key):
    img = Image.open(image_file).convert('RGB')
    img_array = np.array(img)
    
    flat_img = img_array.flatten()
    
    bits = ''
    for pixel in flat_img:
        bits += str(pixel & 1)
        if len(bits) >= 8 and bits[-8:] == '11111111':
            break
    
    encrypted_msg = bits_to_bytes(bits)
    message = decrypt_message(encrypted_msg, secret_key)
    
    if message:
        return message
    else:
        return "Sorry, couldn't reveal the secret. Check your key or the image!"

# --- Routes ---
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/encode', methods=['GET', 'POST'])
def encode():
    if request.method == 'POST':
        image = request.files['image']
        message = request.form['message']
        password = request.form['password']
        
        filename = secure_filename(image.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        image.save(filepath)

        encoded_image_path = encode_image(filepath, message, password)
        return send_file(encoded_image_path, as_attachment=True)
    
    return render_template('encode.html')

@app.route('/decode', methods=['GET', 'POST'])
def decode():
    message = None
    if request.method == 'POST':
        image = request.files['image']
        password = request.form['password']
        
        filename = secure_filename(image.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        image.save(filepath)

        message = decode_image(filepath, password)
    
    return render_template('decode.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
